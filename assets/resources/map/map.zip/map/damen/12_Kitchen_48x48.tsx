<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="12_Kitchen_48x48" tilewidth="32" tileheight="32" tilecount="1752" columns="24">
 <image source="map/damen/12_Kitchen_48x48.png" width="768" height="2352"/>
</tileset>
