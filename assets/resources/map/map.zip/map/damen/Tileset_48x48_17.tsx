<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tileset_48x48_17" tilewidth="32" tileheight="32" tilecount="336" columns="16">
 <image source="Tileset_48x48_17.png" width="528" height="672"/>
</tileset>
