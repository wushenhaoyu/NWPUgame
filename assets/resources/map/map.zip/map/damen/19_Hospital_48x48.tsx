<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="19_Hospital_48x48" tilewidth="32" tileheight="32" tilecount="3960" columns="24">
 <image source="map/damen/19_Hospital_48x48.png" width="768" height="5280"/>
</tileset>
