<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="16_Office_32x32" tilewidth="32" tileheight="32" tilecount="3040" columns="32">
 <image source="16_Office_32x32.png" width="1024" height="3040"/>
</tileset>
