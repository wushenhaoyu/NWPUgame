<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="18_Jail_48x48" tilewidth="32" tileheight="32" tilecount="1608" columns="24">
 <image source="18_Jail_48x48.png" width="768" height="2160"/>
</tileset>
